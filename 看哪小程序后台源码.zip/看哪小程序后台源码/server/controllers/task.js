const { uploader } = require('../qcloud')
const { mysql } = require('../qcloud')

module.exports = async ctx => {
  console.log(ctx.request.body);
  var title = ctx.request.body.title;
  var description = ctx.request.body.description;
  var adress = ctx.request.body.adress;
  var gold = ctx.request.body.gold;
  var longitude = ctx.request.body.longitude;
  var latitude = ctx.request.body.latitude;
  var skey = ctx.request.body.skey;
  var openID = null;
  

  console.log("title:" + title + " description:" + description + " adress:"+adress+' gold'+gold + skey + 'skey');
  console.log(adress);

  await mysql('cAuth').select('open_id').from('cSessionInfo').where('skey',skey).then(res => {
    openID = res[0]['open_id'];
  })


  await mysql('Question').insert({ 
    title: title,
    description: description,
    adress : adress,
    questionGold : gold,
    openID : openID,
    state : 1,
    answerSum : 0,
    latitude : latitude,
    longitude : longitude
  }).then(res => {
    console.log('数据插入');
    console.log(res);
  })

  await mysql('cAuth').select('gold').from('cSessionInfo').where({
    open_id: openID
  }).then(res => {
    ctx.state.data = { msg: res }
  })

  await mysql('cSessionInfo').where('skey', skey).decrement('gold', gold).then(res => {
    console.log(res);
  })

  await mysql('cAuth').select('gold').from('cSessionInfo').where({
    skey : skey
  }).then(res => {
    ctx.state.data = { msg: res }
  })

}



