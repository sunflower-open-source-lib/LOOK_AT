  const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var respon = {};
  console.log("second Page get test");
  var questionID = ctx.query.questionID;  
  console.log(questionID); 
  var user_info = null;
  await mysql('cAuth').select('user_info' ).from('Question').innerJoin('cSessionInfo', 'Question.openID', 'cSessionInfo.open_id').where('questionID', questionID).then(res => {
    user_info = res[0]['user_info'];
    respon['user_info'] = user_info;
  })
  await mysql('cAuth').select('questionGold', 'answerSum','longitude','latitude','title','description','adress','state').from('Question').where('questionID', questionID).then(res => {
    console.log(res);
    respon['question'] = res;
  })
  await mysql('cAuth').select('image_url', 'comments', 'answerTime', 'user_info','answerID','best').from('Answer').innerJoin('cSessionInfo', 'Answer.openID', 'cSessionInfo.open_id').where('questionID', questionID).then(res => {
    console.log(res);
    respon['answer'] = res;
  })
  console.log(respon);
  ctx.state.data = { msg: respon }
}