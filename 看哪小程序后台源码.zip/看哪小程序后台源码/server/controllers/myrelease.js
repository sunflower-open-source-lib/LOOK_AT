const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  var respon = {};
  
  await mysql('cAuth').select('user_info').from('cSessionInfo').where('skey',skey).then(res => {
    respon['user_info'] = res[0]['user_info'];
  })

  await mysql('cAuth').select('questionID','questionGold','answerSum','longitude','latitude','title','description','adress','state').from('Question').innerJoin('cSessionInfo', 'Question.openID', 'cSessionInfo.open_id').where('skey', skey).then(res => {
    console.log(res);
    respon['question'] = res;
  })
  ctx.state.data = { msg: respon };
}