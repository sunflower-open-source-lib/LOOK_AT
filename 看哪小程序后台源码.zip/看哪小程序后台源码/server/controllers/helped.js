const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  var questionID = null;
  var openID = null;
  var respon = {};
  console.log('帮助过的')

  await mysql('cAuth').select('user_info','open_id').from('cSessionInfo').where('skey', skey).then(res => {
    console.log(res);
    //respon['user_info'] = res[0]['user_info'];
    openID = res[0]['open_id'];
  })

  console.log(openID);

  var length = null;
  var res1 = null;
  await mysql('cAuth').distinct('questionID', 'questionGold', 'answerSum', 'longitude', 'latitude', 'title', 'description', 'adress', 'state').select().from('getQuestion').innerJoin('Question', 'getQuestion.getQuestionID', 'Question.questionID').where({
    open_id: openID,
    finishState: 0
  }).then(res => {
    res1 = res;
    console.log(res);
    length = res.length;
    respon['question'] = res;
  })

  respon['question_userInfo'] = [];
  for (var i = 0; i < length; i++) {
    await mysql('cAuth').select('user_info').from('cSessionInfo').innerJoin('Question', 'Question.openID', 'cSessionInfo.open_id').where({
      questionID: res1[i]['questionID']
    }).then(res => {
      respon['question_userInfo'][i] = res;
    })
  }
  ctx.state.data = { msg: respon };
}
