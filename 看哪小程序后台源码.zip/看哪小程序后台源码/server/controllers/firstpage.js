const { mysql } = require('../qcloud')

module.exports = async ctx => {
 
  console.log("111")
  var city0 = ctx.query.city;
  var query = '%'+city0+'%';
  var longitude = ctx.query.longitude;
  var latitude = ctx.query.latitude;

  console.log("city :" + city0 + "longitude: " +longitude + "latitude" + latitude);

  await mysql('cAuth').select('openID', 'questionGold', 'answerSum', 'longitude', 'latitude', 'title', 'description', 'user_info','adress','questionID').from('Question').innerJoin('cSessionInfo', 'Question.openID', 'cSessionInfo.open_id').where({
    state: 1
  }).andWhere('adress', 'like', query).orderBy('questionGold', 'desc').then(res => {
    console.log(res[0]['appid']);
    console.log("hello everybo");
    console.log('res:' + res);
    var length = res.length;
    console.log("length: "+length);
    var i = 0;
    console.log("type: " + typeof (res));
    ctx.state.data = { msg: res }
    console.log("how");
    
  })
}