const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  var openID = null;
  var questionID = null;
  var respon = {};
  console.log("test0")

  await mysql('cAuth').select('open_id').from('cSessionInfo').where('skey', skey).then(res => {
    openID = res[0]['open_id'];
  })

  var length = null;
  var res1 = null;
  await mysql('cAuth').select('questionID', 'questionGold', 'answerSum', 'longitude', 'latitude', 'title', 'description', 'adress', 'state').from('getQuestion').innerJoin('Question', 'getQuestion.getQuestionID', 'Question.questionID').where({
    open_id: openID,
    finishState : 1,
    state : 1
    }).then(res => {
    res1 = res;
    console.log(res);
    length = res.length;
    respon['question'] = res;
  })
  console.log("test1");
  respon['question_userInfo'] = [];
  for(var i = 0; i < length; i++){
    await mysql('cAuth').select('user_info').from('cSessionInfo').innerJoin('Question', 'Question.openID', 'cSessionInfo.open_id').where({
      questionID: res1[i]['questionID']
    }).then(res => {
      respon['question_userInfo'][i] = res;
    })
  }
  
  console.log("test2");
  ctx.state.data = { msg: respon }; 
}