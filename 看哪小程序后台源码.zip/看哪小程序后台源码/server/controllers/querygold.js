const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;

  await mysql('cAuth').select('gold').from('cSessionInfo').where('skey', skey).then(res => {
    ctx.state.data = { msg: res };
    console.log(res);
  })

}
