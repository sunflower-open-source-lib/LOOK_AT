const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  var questionID = ctx.request.body.questionID;
  var openID = null;``

  await mysql('cAuth').select('open_id').from('cSessionInfo').where('skey', skey).then(res => {
    openID = res[0]['open_id'];
  })
  
  await mysql('Question').where('questionID', questionID).increment('questionGold', 1).then(res => {
    console.log(res);
  })

  await mysql('cSessionInfo').where('skey',skey).decrement('gold',1).then(res => {
    console.log(res);
  })
  var respon = {};
  await mysql('cAuth').select('gold').from('cSessionInfo').where({
    skey: skey,
  }).then(res => {
    respon['gold'] = res[0]['gold'];
    console.log(res);
  })
  await mysql('cAuth').select('questionGold').from('Question').where({
    questionID : questionID
  }).then(res => {
    respon['questionGold'] = res[0]['questionGold'];
    console.log(res);
  })
  respon['mes'] = '点赞成功';  
  ctx.state.data = { msg: respon };
}
