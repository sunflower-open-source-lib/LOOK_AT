const { mysql } = require('../qcloud')

module.exports = async ctx => {

  console.log("111")
  var question  = '%'+ ctx.query.question + '%';

  console.log("question" + question);

  await mysql('cAuth').select('openID', 'questionGold', 'answerSum', 'longitude', 'latitude', 'title', 'description', 'user_info', 'adress', 'questionID').from('Question').innerJoin('cSessionInfo', 'Question.openID', 'cSessionInfo.open_id').where('adress', 'like', question).orderBy('questionGold', 'desc').then(res => {
    console.log("hello everybo");
    console.log(res);
    var length = res.length;
    console.log("length: " + length);
    
    console.log("type: " + typeof (res));
    ctx.state.data = { msg: res }
    console.log("how");

  })
}