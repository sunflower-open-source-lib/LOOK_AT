const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  var questionID = ctx.request.body.questionID;
  var openID = null;
  var flag = 0;

  console.log("接受任务");
  await mysql('cAuth').select('open_id').from('cSessionInfo').where('skey', skey).then(res => {
    openID = res[0]['open_id'];
  })
  console.log("test");
  await mysql('cAuth').select('*').from('getQuestion').where({
    open_id : openID,
    getQuestionID : questionID,
    finishState : 1
    }).then(res => {
    if(res[0] == null){
      console.log('没有查到');
      flag = 1; //可以接受任务插入数据
    }
  })
  var respon = {};
  if(flag == 1){
    await mysql('getQuestion').insert({  
      open_id: openID,
      getQuestionID: questionID,
      finishState: 1
    }).then(res0 => {
      respon['res'] = 0;
      respon['msg'] = '接收任务成功';
      ctx.state.data = { msg: respon };//接收任务成功
    })
  }
  else{
    respon['res'] = 1;
    respon['msg'] = "你已经接过这个任务了";
    console.log("你已经接过这个任务了")
    console.log(respon);
    ctx.state.data = { msg: respon };//已经接受了任务并且未完成
  }
}