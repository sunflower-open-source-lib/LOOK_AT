const { uploader } = require('../qcloud')
const { mysql } = require('../qcloud')
var formidable = require('formidable');

module.exports = async ctx => {
  console.log("我帮你拍");
  var comments = null;
  var img_url = null;
  var questionID = null;
  var skey = null;
  var form = new formidable.IncomingForm();
  //bluebird.promisify(form.parse);
  form.parse(ctx.req, async function (err, fields, files) {
    if (err) { throw err; return; }
    console.log(fields);//{ name: base64字符串 }
    questionID = fields['questionID']
    comments = fields['comments']
    skey = fields['skey']
    //ctx.state.data = fields.toString();
  });
  const data = await uploader(ctx.req).then(data => {
    console.log(data);
    img_url = data['imgUrl'];
    console.log(img_url);
    ctx.state.data = data;
  })
  await mysql('cAuth').select('open_id').from('cSessionInfo').where('skey', skey).then(res => {
    openID = res[0]['open_id'];
    console.log(openID);
  })
  await mysql('Question').where('questionID', questionID).increment('answerSum', 1).then(res => {
    console.log(res);
  })
  await mysql('getQuestion').where({
    getQuestionID : questionID,
    open_id : openID,
  }).update('finishState',0).then(res => {
    console.log(res);
  })
  await mysql('Answer').insert({
    openID : openID, 
    comments : comments,
    image_url : img_url,
    questionID : questionID,
    best : 1
  }).then(res => {
    console.log('数据插入');
    console.log(res);
   // ctx.state.data = { msg: res }
  })
  await mysql('cSessionInfo').where('open_id', openID).increment('gold', 1).then(res => {
    console.log(res);
  })
  await mysql('cAuth').select('gold').from('cSessionInfo').where('open_id', openID).then(res => {
    ctx.state.data = { msg: res }
  })
}
