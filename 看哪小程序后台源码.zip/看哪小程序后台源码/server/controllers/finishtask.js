const { mysql } = require('../qcloud')

module.exports = async ctx => {
  console.log('test0')
  var skey = ctx.request.body.skey;
  var questionID = ctx.request.body.questionID;
  var bestAnswerID= ctx.request.body.bestAnswerID;
  console.log('test1');
  var questionGold = null;
  await mysql('cAuth').select( 'questionGold',).from('Question').where({
    questionID : questionID
  }).then(res => {
    questionGold = res[0]['questionGold'];
  })

  await mysql('Answer').update('best',0).where('answerID',bestAnswerID).then(res => {
    console.log(res);
  })
  await mysql('Question').update('state',0).where('questionID',questionID).then(res => {
    console.log(res)
  })
  var openID = null;
  await mysql('cAuth').select('open_id').from('Answer').innerJoin('cSessionInfo', 'Answer.openID', 'cSessionInfo.open_id').where({
    answerID: bestAnswerID
  }).then(res => {
    openID = res[0]['open_id'];
  })  
  await mysql('cSessionInfo').where('open_id', openID).increment('gold', questionGold).then(res => {
    console.log(res);
  })
  await mysql('cAuth').select('gold').from('cSessionInfo').where({
    open_id : openID
  }).then(res => {
    res[0]['mes'] = 0;
    ctx.state.data = { msg: res }
  })  
}