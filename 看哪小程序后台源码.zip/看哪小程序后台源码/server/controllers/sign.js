const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  console.log(skey);
  var monthList = { 'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6, 'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11,'Dec':12}
  var oDate = new Date(); //实例一个时间对象；
  var oYear = oDate.getFullYear();   //获取系统的年；
  var oMonth = oDate.getMonth() + 1;   //获取系统月份，由于月份是从0开始计算，所以要加1
  var oDay = oDate.getDate();
  var month,day,year,month0;
  await mysql('cAuth').select('signTime').from('cSessionInfo').where('skey',skey).then(res => {
    var signTime = res[0]['signTime'].toString();
    month0 = signTime.split(" ")[1];
    console.log(month0)
    month = monthList[month0];
    console.log(month);
    day = signTime.split(" ")[2];
    year = signTime.split(" ")[3];
    console.log(signTime);
    console.log('year:' + year+' month:' + month+' day:'+day);
    console.log(typeof(signTime));
  })
  if (day != oDay||year != oYear||month != oMonth){
    var sql = 'update cSessionInfo set signTime = now() where skey = ' + '\''+skey+'\'';
    console.log('日期不一样');
    await mysql('cSessionInfo').where('skey', skey).increment('gold', 5).then(res => {
      console.log(res);
    })
    await mysql.raw(sql).then(res => {
      console.log(res);
    })
    await mysql('cAuth').select('gold').from('cSessionInfo').where({
      skey : skey,
    }).then(res => {
      res[0]['mes'] = '签到成功';
      console.log(res);
      ctx.state.data = { msg: res }
    })
  }
  else {
    await mysql('cAuth').select('gold').from('cSessionInfo').where({
      skey: skey,
    }).then(res => {
      res[0]['mes'] = '今日已签到';
      console.log(res);
      ctx.state.data = { msg: res }
    })
  }
}