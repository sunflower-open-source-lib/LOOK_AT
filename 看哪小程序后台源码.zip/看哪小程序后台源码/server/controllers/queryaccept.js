const { mysql } = require('../qcloud')

module.exports = async ctx => {
  var skey = ctx.request.body.skey;
  var questionID = ctx.request.body.questionID;
  var openID = null;
  var flag = 0;

  await mysql('cAuth').select('open_id').from('cSessionInfo').where('skey', skey).then(res => {
    openID = res[0]['open_id'];
  })
  console.log("test");
  await mysql('cAuth').select('*').from('getQuestion').where({
    open_id: openID,
    getQuestionID: questionID,
    finishState: 1
  }).then(res => {
    if (res[0] == null) {
      console.log('没有查到');
      flag = 1;
    }
  })
  if(flag){
    ctx.state.data = { msg: 0 }; //之前没有接过
  }
  else{
    ctx.state.data = { msg: 1 }; //之前没有接过
  }
}